/*
===============================================================================
 Name        : DrawLine.c
 Author      : Akash Aggarwal
 SJSU ID     : 014613313
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#include <cr_section_macros.h>
#include <NXP/crp.h>
#include "LPC17xx.h"                        /* LPC17xx definitions */
#include "ssp.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>



/* Be careful with the port number and location number, because

some of the location may not exist in that port. */

#define PORT_NUM            1


uint8_t src_addr[SSP_BUFSIZE];
uint8_t dest_addr[SSP_BUFSIZE];


#define ST7735_TFTWIDTH 127
#define ST7735_TFTHEIGHT 159

#define ST7735_CASET 0x2A
#define ST7735_RASET 0x2B
#define ST7735_RAMWR 0x2C
#define ST7735_SLPOUT 0x11
#define ST7735_DISPON 0x29



#define swap(x, y) {x = x + y; y = x - y; x = x - y ;}

// defining color values

#define LIGHTBLUE 0x00FFE0
#define GREEN 0x00FF00
#define DARKBLUE 0x00008B
#define BLACK 0x000000
#define BLUE 0x0007FF
#define RED 0xFF0000
#define MAGENTA 0x00F81F
#define WHITE 0xFFFFFF
#define PURPLE 0xCC33FF



int _height = ST7735_TFTHEIGHT;
int _width = ST7735_TFTWIDTH;

int cursor_x = 0, cursor_y = 0;
int rotation = 0;
int textsize  = 1;
int x_diff = 64;
int y_diff = 80;

struct point_coordinate{
	int x;
	int y;
};

int cam_x = 140;
int cam_y = 140;
int cam_z = 140;


int light_x = -50;
int light_y = 50;
int light_z = 200;


#define LOCATION_NUM        0

uint8_t src_addr[SSP_BUFSIZE];
uint8_t dest_addr[SSP_BUFSIZE];
int colstart = 0;
int rowstart = 0;


typedef struct Point3D
{
	float x;
	float y;
	float z;
} Point3D;

typedef struct Point
{
	float x;
	float y;
} Point;

void spiwrite(uint8_t c)

{

 int pnum = 1;

 src_addr[0] = c;

 SSP_SSELToggle( pnum, 0 );

 SSPSend( pnum, (uint8_t *)src_addr, 1 );

 SSP_SSELToggle( pnum, 1 );

}



void writecommand(uint8_t c)

{

 LPC_GPIO0->FIOCLR |= (0x1<<21);

 spiwrite(c);

}



void writedata(uint8_t c)

{

 LPC_GPIO0->FIOSET |= (0x1<<21);

 spiwrite(c);

}



void writeword(uint16_t c)

{

 uint8_t d;

 d = c >> 8;

 writedata(d);

 d = c & 0xFF;

 writedata(d);

}



void write888(uint32_t color, uint32_t repeat)

{

 uint8_t red, green, blue;

 int i;

 red = (color >> 16);

 green = (color >> 8) & 0xFF;

 blue = color & 0xFF;

 for (i = 0; i< repeat; i++) {

  writedata(red);

  writedata(green);

  writedata(blue);

 }

}



void setAddrWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)

{

 writecommand(ST7735_CASET);

 writeword(x0);

 writeword(x1);

 writecommand(ST7735_RASET);

 writeword(y0);

 writeword(y1);

}


void draw_rect(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint32_t color)

{

 int16_t i;

 int16_t width, height;

 width = x1-x0+1;

 height = y1-y0+1;

 setAddrWindow(x0,y0,x1,y1);

 writecommand(ST7735_RAMWR);

 write888(color,width*height);

}



void lcddelay(int ms)

{

 int count = 24000;

 int i;

 for ( i = count*ms; i--; i > 0);

}



void lcd_init()

{

 int i;
 // Set pins P0.16, P0.21, P0.22 as output
 LPC_GPIO0->FIODIR |= (0x1<<6);

 LPC_GPIO0->FIODIR |= (0x1<<21);

 LPC_GPIO0->FIODIR |= (0x1<<22);

 // Hardware Reset Sequence
 LPC_GPIO0->FIOSET |= (0x1<<22);
 lcddelay(500);

 LPC_GPIO0->FIOCLR |= (0x1<<22);
 lcddelay(500);

 LPC_GPIO0->FIOSET |= (0x1<<22);
 lcddelay(500);

 // initialize buffers
 for ( i = 0; i < SSP_BUFSIZE; i++ )
 {

   src_addr[i] = 0;
   dest_addr[i] = 0;
 }

 // Take LCD display out of sleep mode
 writecommand(ST7735_SLPOUT);
 lcddelay(200);

 // Turn LCD display on
 writecommand(ST7735_DISPON);
 lcddelay(200);

}
void fillrect(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint32_t color)

{

 int16_t i;

 int16_t width, height;

 width = x1-x0+1;

 height = y1-y0+1;

 setAddrWindow(x0,y0,x1,y1);

 writecommand(ST7735_RAMWR);

 write888(color,width*height);

}



void draw_pixel(int16_t x, int16_t y, uint32_t color)

{

 if ((x < 0) || (x >= _width) || (y < 0) || (y >= _height))

 return;

 setAddrWindow(x, y, x + 1, y + 1);

 writecommand(ST7735_RAMWR);

 write888(color, 1);

}



/*****************************************************************************


** Descriptions:        Draw line function

**

** parameters:           Starting point (x0,y0), Ending point(x1,y1) and color

** Returned value:        None

**

*****************************************************************************/


void draw_line(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint32_t color)

{

 int16_t slope = abs(y1 - y0) > abs(x1 - x0);

 if (slope) {

  swap(x0, y0);

  swap(x1, y1);

 }

 if (x0 > x1) {

  swap(x0, x1);

  swap(y0, y1);

 }

 int16_t dx, dy;

 dx = x1 - x0;

 dy = abs(y1 - y0);

 int16_t err = dx / 2;

 int16_t ystep;

 if (y0 < y1) {

  ystep = 1;

 }

 else {

  ystep = -1;

 }

 for (; x0 <= x1; x0++) {

  if (slope) {

   draw_pixel(y0, x0, color);

  }

  else {

   draw_pixel(x0, y0, color);

  }

  err -= dy;

  if (err < 0) {

   y0 += ystep;

   err += dx;

  }

 }

}


struct point_coordinate world_to_viewer_coord (int x_w, int y_w, int z_w)
{
	int scrn_x, scrn_y, Dist=70, x_diff=ST7735_TFTWIDTH/2, y_diff=ST7735_TFTHEIGHT/2;
	double x_p, y_p, z_p, theta, phi, rho;
	struct point_coordinate screen;
	theta = acos(cam_x/sqrt(pow(cam_x,2)+pow(cam_y,2)));
	phi = acos(cam_z/sqrt(pow(cam_x,2)+pow(cam_y,2)+pow(cam_z,2)));
	//theta = 0.785;
	//phi = 0.785;
	rho= sqrt((pow(cam_x,2))+(pow(cam_y,2))+(pow(cam_z,2)));
	x_p = (y_w*cos(theta))-(x_w*sin(theta));
	y_p = (z_w*sin(phi))-(x_w*cos(theta)*cos(phi))-(y_w*cos(phi)*sin(theta));
	z_p = rho-(y_w*sin(phi)*cos(theta))-(x_w*sin(phi)*cos(theta))-(z_w*cos(phi));
            scrn_x = x_p*Dist/z_p;
	scrn_y = y_p*Dist/z_p;
	scrn_x = x_diff+scrn_x;
	scrn_y = y_diff-scrn_y;
	screen.x = scrn_x;
	screen.y = scrn_y;
	return screen;
}

void draw_coordinates ()
{
	struct point_coordinate lcd;
	int x1,y1,x2,y2, x3,y3,x4,y4;
	  	lcd = world_to_viewer_coord (0,0,0);
	  	x1=lcd.x;
	  	y1=lcd.y;
	  	lcd = world_to_viewer_coord (180,0,0);
	  	x2=lcd.x;
	  	y2=lcd.y;
	  	lcd = world_to_viewer_coord (0,180,0);
	  	x3=lcd.x;
	  	y3=lcd.y;
	  	lcd = world_to_viewer_coord (0,0,180);
	  	x4=lcd.x;
	  	y4=lcd.y;

	  	draw_line(x1,y1,x2,y2,RED);	//x axis  red
	  	draw_line(x1,y1,x3,y3,0x0000FF00);	//y axis  green
	  	draw_line(x1, y1, x4, y4,0x000000FF);  	//z axis  blue
}

void rotate_point(int *x, int *y, float angle)
{
	int temp_x = *x , temp_y = *y;
	angle = angle*(3.14285/180);
	float cos_rotation = cos(angle);
	float sin_rotation = sin(angle);

	*x = temp_x*cos_rotation - temp_y*sin_rotation;
	*y = temp_x*sin_rotation + temp_y*cos_rotation;
}

void draw_cube(int start_pnt, int size)
{
	struct point_coordinate lcd;
	int x1,y1,x2,y2,x3,y3,x4,y4,x5,y5,x6,y6,x7,y7;
	cam_x = 140;
	cam_y = 140;
	cam_z = 140;


	lcd = world_to_viewer_coord (start_pnt,start_pnt,(size+start_pnt));
	x1=lcd.x;
	y1=lcd.y;
	lcd = world_to_viewer_coord ((size+start_pnt),start_pnt,(size+start_pnt));
	x2=lcd.x;
	y2=lcd.y;
	lcd = world_to_viewer_coord ((size+start_pnt),(size+start_pnt),(size+start_pnt));
	x3=lcd.x;
	y3=lcd.y;
	lcd = world_to_viewer_coord (start_pnt,(size+start_pnt),(size+start_pnt));
	x4=lcd.x;
	y4=lcd.y;
	lcd = world_to_viewer_coord ((size+start_pnt),start_pnt,start_pnt);
	x5=lcd.x;
	y5=lcd.y;
	lcd = world_to_viewer_coord ((size+start_pnt),(size+start_pnt),start_pnt);
	x6=lcd.x;
	y6=lcd.y;
	lcd = world_to_viewer_coord (start_pnt,(size+start_pnt),start_pnt);
	x7=lcd.x;
	y7=lcd.y;
	draw_line(x1, y1, x2, y2,0x00FF0000);
	draw_line(x2, y2, x3, y3,0x00FF0000);
	draw_line(x3, y3, x4, y4,0x00FF0000);
	draw_line(x4, y4, x1, y1,0x00FF0000);
	draw_line(x2, y2, x5, y5,0x00FF0000);
	draw_line(x5, y5, x6, y6,0x00FF0000);
	draw_line(x6, y6, x3, y3,0x00FF0000);
	draw_line(x6, y6, x7, y7,0x00FF0000);
	draw_line(x7, y7, x4, y4,0x00FF0000);
}


void fill_rotated_cube(int start_x, int start_y, int start_z, int size , float angle)
{
	struct point_coordinate s1;
	int xsize = start_x + size, ysize = start_y + size, zsize = start_z + size;
	int i,j;
	int x,y;

	for(i = start_x; i < xsize; i++)
	{
		for(j = start_y; j < ysize; j++)
		{
			x = i;
			y = j;
			rotate_point(&x, &y, angle);
			s1=world_to_viewer_coord(x,y, zsize);	//top fill green
			draw_pixel(s1.x,s1.y, RED);

		}
	}

	for(i = start_y; i < ysize; i++)
	{
		for(j = start_z; j < zsize; j++)
		{
			x = xsize; y = i;
			rotate_point(&x, &y, angle);
			s1=world_to_viewer_coord(x, y, j);	// left fill pink
			draw_pixel(s1.x,s1.y, 0xFFA500);
		}
	}

	for(i = start_x; i < xsize; i++)
	{
		for(j = start_z; j < zsize; j++)
		{
			x = i;
			y = start_y;
			rotate_point(&x, &y, angle);
			s1=world_to_viewer_coord(x, y, j);	// right fill yellow
			draw_pixel(s1.x,s1.y,0x00FFFF00);
		}
	}
}

void draw_HorizontalLine(int16_t x, int16_t y, int16_t width, uint32_t color)
{
	draw_line(x, y, x+width-1, y, color);
}

void fill_Triangle(int16_t x0, int16_t y0,int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint32_t color) {
	int16_t x, y, j, l;
	if (y0 > y1) {
		swap(y0, y1);
		swap(x0, x1);
	}
	if (y1 > y2) {
		swap(y2, y1);
		swap(x2, x1);
	}
	if (y0 > y1) {
		swap(y0, y1);
		swap(x0, x1);
	}
	if(y0 == y2) {
		x = y = x0;
		if(x1 < x) x = x1;
		else if(x1 > y) y = x1;

		if(x2 < x) x = x2;
		else if(x2 > y) y = x2;
		draw_HorizontalLine(x, y0, y-x+1, color);
		return;
	}

	int16_t dx01 = x1 - x0, dy01 = y1 - y0, dx02 = x2 - x0, dy02 = y2 - y0, dx12 = x2 - x1, dy12 = y2 - y1;
	int32_t sa = 0, sb = 0;

	if(y1 == y2) l = y1;
	else l = y1-1;

	for(j=y0; j<=l; j++) {
		x = x0 + sa / dy01;
		y = x0 + sb / dy02;
		sa += dx01;
		sb += dx02;
		if(x > y) swap(x,y);
		draw_HorizontalLine(x, j, y-x+1, color);
	}
	sa = dx12 * (j - y1);
	sb = dx02 * (j - y0);
	for(; j<=y2; j++) {
		x = x1 + sa / dy12;
		y = x0 + sb / dy02;
		sa += dx12;
		sb += dx02;
		if(x > y) swap(x,y);
		draw_HorizontalLine(x, j, y-x+1, color);
	}
}

void draw_shadow(double x[], double y[], double z[], int size, double xShad, double yShad, double zShad)
{
	int xs[8]={0}, ys[8]={0}, zs[8]={0};
	struct point_coordinate s5,s6,s7,s8;
	int i;
	for(i=4; i<8; i++){
		xs[i]=x[i]-((z[i]/(zShad-z[i]))*(xShad-x[i]));
		ys[i]=y[i]-((z[i]/(zShad-z[i]))*(yShad-y[i]));
		zs[i]=z[i]-((z[i]/(zShad-z[i]))*(zShad-z[i]));
	}
	s5 = world_to_viewer_coord (xs[4],ys[4],zs[4]);
	s6 = world_to_viewer_coord (xs[5],ys[5],zs[5]);
	s7 = world_to_viewer_coord (xs[6],ys[6],zs[6]);
	s8 = world_to_viewer_coord (xs[7],ys[7],zs[7]);

	draw_line(s5.x, s5.y, s6.x, s6.y, BLACK);
	draw_line(s6.x, s6.y, s7.x, s7.y, BLACK);
	draw_line(s7.x, s7.y, s8.x, s8.y, BLACK);
	draw_line(s8.x, s8.y, s5.x, s5.y, BLACK);

	fill_Triangle(s5.x, s5.y, s6.x, s6.y, s7.x, s7.y,DARKBLUE);
	fill_Triangle(s5.x, s5.y, s7.x, s7.y, s8.x, s8.y,DARKBLUE);
}

int calculate_intensity(int16_t xPs, int16_t yPs, int16_t zPs, int16_t xPi, int16_t yPi,
	int16_t zPi, int16_t k) {
	double cosVal;
	double r = sqrt(
	pow((zPs - zPi), 2) + pow((yPs - yPi), 2) + pow((xPs - xPi), 2));
	double rcos = sqrt(pow((zPs - zPi), 2));
	cosVal = rcos / r;
	return (255 * k * cosVal) / pow(r, 2);
}

void diffused_reflection(int size) {
	struct point_coordinate lcd;
	struct point_coordinate tmp;
	int x1, y1, x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, x7, y7, x8, y8;
	lcd = world_to_viewer_coord(0, 0, 0);
	x1 = lcd.x;
	y1 = lcd.y;
	lcd = world_to_viewer_coord(size, 0, 0);
	x2 = lcd.x;
	y2 = lcd.y;
	lcd = world_to_viewer_coord(0, size, 0);
	x3 = lcd.x;
	y3 = lcd.y;
	lcd = world_to_viewer_coord(0, 0, size);
	x4 = lcd.x;
	y4 = lcd.y;
	lcd = world_to_viewer_coord(size, 0, size);
	x5 = lcd.x;
	y5 = lcd.y;
	lcd = world_to_viewer_coord(size, size, 0);
	x6 = lcd.x;
	y6 = lcd.y;
	lcd = world_to_viewer_coord(size, size, size);
	x7 = lcd.x;
	y7 = lcd.y;
	lcd = world_to_viewer_coord(0, size, size);
	x8 = lcd.x;
	y8 = lcd.y;

	for (int i = 0; i <= size; i++) {
		for (int j = 0; j <= size; j++)
		{

			tmp = world_to_viewer_coord (size,i,j);
			int kR = calculate_intensity(light_x, light_y, light_z, i, j, size, 255);

			if (kR + 170 > 255)
				kR = 255;
			else
				kR += 170;

			uint32_t color = 0x000000;
			color |= ((kR |= 0x000000) << 16);
			color |= (0x000000 << 8);
			color |= 0x000000;
			draw_pixel(tmp.x, tmp.y, color);
		}
	}
    for (int i = 0; i <= size; i++) {
    	for (int j = 0; j <= size; j++) {
    		tmp = world_to_viewer_coord(i, j, size);

    	int kR = calculate_intensity(light_x, light_y, light_z, size, i, j, 255);
    	if (kR + 170 > 255) {
    	    kR = 255;
    	    } else {
    	    	kR += 170;
    	    }
    	uint32_t color = 0x000000;
    	color |= (0x000000 << 16);
    	color |= ((kR |= 0x000000) << 8);
    	color |= 0x000000;
    	draw_pixel(tmp.x,tmp.y,color);
    	}
    }
    for (int i = 0; i <= size; i++) {
        	for (int j = 0; j <= size; j++) {
        	tmp = world_to_viewer_coord (i,size,j);
        	int kR = calculate_intensity(light_x, light_y, light_z, size, i, j, 255);
        	if (kR + 170 > 255) {
        	    kR = 255;
        	    } else {
        	    	kR += 170;
        	    }
        	uint32_t color = 0x000000;
        	color |= (0x000000 << 16);
        	color |= (0x000000 << 8);
        	color |= (kR |= 0x000000);
        	draw_pixel(tmp.x,tmp.y,color);
        	}
        }

}

void draw_A(int start_pnt, int size)
{
struct point_coordinate p1;
int i,j;
size=size+start_pnt;
int map[size][size];

for(i=0;i<size;i++)
{
for(j=0;j<size;j++)
{
if(i>=start_pnt+5 && j>=start_pnt+10 && j<=size-10 && i<=start_pnt+15)
map[i][j]=1;
else if(i>=start_pnt+15 && j>=start_pnt+10 && j<=start_pnt+20 && i<=size-5)
map[i][j]=1;
else if(i>=start_pnt+30 && j>=start_pnt+10 && j<=size-10 && i<=start_pnt+40)
map[i][j]=1;
else if(i>=start_pnt+15 && j>=start_pnt+50 && j<=start_pnt+60 && i<=size-5)
map[i][j]=1;
else
map[i][j]=0;
}
}
for(i=0;i<size;i++)
{
for(j=0;j<size;j++)
{
if(map[i][j]==1)
{
p1 = world_to_viewer_coord(j,i,size);
draw_pixel(p1.x,p1.y,0x008E35EF);
}
else if(map[i][j]==0)
{
p1 = world_to_viewer_coord(j,i,size);
}
}
}
}

int main (void)
{

	uint32_t pnum = PORT_NUM;
	 int size = 70, start_pnt = 0;
     double x[8] = {start_pnt,(start_pnt+size),(start_pnt+size),start_pnt,start_pnt,(start_pnt+size),(start_pnt+size),start_pnt};
	 double y[8] = {start_pnt, start_pnt, start_pnt+size, start_pnt+size, start_pnt, start_pnt, (start_pnt+size), (start_pnt+size) };
	 double z[8] = {start_pnt, start_pnt, start_pnt, start_pnt, (start_pnt+size), (start_pnt+size), (start_pnt+size), (start_pnt+size)};

	 pnum = 1 ;

	 if ( pnum == 1 )
	 SSP1Init();

	 else
	 puts("Port number is not correct");

	 for (int i = 0; i < SSP_BUFSIZE; i++ )
	   {
	     src_addr[i] = (uint8_t)i;
	     dest_addr[i] = 0;
	   }
	   //To initialize LCD
	   	lcd_init();
	   	fillrect(0, 0, ST7735_TFTWIDTH, ST7735_TFTHEIGHT, WHITE);
	   	draw_coordinates();
	    draw_cube(start_pnt,size);
	    draw_shadow(x, y, z, size, -1000,0,1000);
        diffused_reflection(size);
	    draw_A(0, size);


	   	return 0;

}
