
#include <stdio.h>
#include <stdlib.h>
#include "coord.h"


point virtualToNativeCoord(point* virt_coord)
{
	point native_coord = {0};

	native_coord.x = virt_coord->x + (DISPLAY_WIDTH_PIXELS/2);
	native_coord.y = (DISPLAY_HEIGHT_PIXES/2) - virt_coord->y;
	return native_coord;
}

